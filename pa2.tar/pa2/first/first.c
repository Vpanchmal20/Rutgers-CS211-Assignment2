#include <stdio.h>
#include <stdlib.h>
double** matrixTranspose(double** matrix, int row, int column){
    	double** matrixNew = (double**)malloc(column * sizeof(double*));
    	int i,j;
    	for(i = 0; i < column;i++)
    	    	matrixNew[i] = (double*) malloc(row * sizeof(double));
	for(i = 0; i < row; i++)
        	for(j = 0; j < column; j++)
            		matrixNew[j][i] = matrix[i][j];
    	return matrixNew;
}
double **matrixMultiply(double** matrix1, double** matrix2, int row1, int col1, int row2, int col2){
	double **matrixProduct = (double**) malloc(row1* sizeof(double*));
        int i,j,k;
    	if(col1 != row2)
        	return NULL;
        for(i = 0; i < row1;i++){
		matrixProduct[i] = (double*)malloc(col2* sizeof(double));
        	for(j = 0;j  < col2;j++)
               		for(k = 0; k < col1;k++)
               			 matrixProduct[i][j] += matrix1[i][k] * matrix2[k][j];
        }
        return matrixProduct;
}
double** matrixInverse(double** matrix, int size){
    	double** identityMatrix, constant, pivot;
    	int i,j,k;
    	identityMatrix = (double**)malloc(size* sizeof(double*));	
    	for(i = 0; i<size; i++){
		identityMatrix[i] = (double*) malloc(size * sizeof(double));
        	for(j = 0; j < size; j++){
            		if(j == i){
                		identityMatrix[i][j] = 1;
				continue;
            		}
            		identityMatrix[i][j] = 0;
        	}
    	}
    	for(i = 0; i < size; i++)
        	for(j = i; j < size; j++){
			if(matrix[j][i] != 0 && j!=i){
                		pivot = matrix[j][i];
                		for(k = 0; k < size; k++){
                    			matrix[j][k] = matrix[j][k] - (pivot * matrix[i][k]);
                    			identityMatrix[j][k] = identityMatrix[j][k] - (pivot * identityMatrix[i][k]);
                		}
            		}
			else if(matrix[j][i] != 1 && j==i){
                		if(matrix[j][i] != 0) {
                    			constant = matrix[j][i];
                    			for (k = 0; k < size; k++) {
                        			matrix[j][k] = matrix[j][k] / constant;
                        			identityMatrix[j][k] = identityMatrix[j][k] / constant;
                    			}
                		} 
				else
                    			printf("error");
            		}
        	}
	for(i = size-1; i >= 0; i--)
        	for(j = i; j >= 0; j--){
            		if(matrix[j][i] != 0 && i != j){
                		constant = matrix[j][i];
                		for(k = 0; k < size; k++){
                    			matrix[j][k] = matrix[j][k] - (matrix[i][k])*constant;
                    			identityMatrix[j][k] = identityMatrix[j][k] - (identityMatrix[i][k])*constant;
				}
            		}
			if (matrix[j][i] != 1 && i == j){
                		constant = matrix[j][i];
                    		matrix[j][i] = matrix[j][i] / constant;
                    		identityMatrix[j][i] = identityMatrix[j][i] / constant;
            		}
        	}
    	return identityMatrix;
}
int main(int argc, char** argv){
    	double **matrix1, **matrix2, **X, **Y, **W, **weights, total = 0;
    	int row1, row2, column, i, j, newCol;
    	FILE *trainPointer, *testPointer;
	trainPointer = fopen(argv[1], "r");
    	fscanf(trainPointer, "%d \n", &column);
	newCol = column + 1;
    	fscanf(trainPointer, "%d \n", &row1);
    	matrix1 = (double**)malloc(row1 * sizeof(double*));
	Y = (double**)malloc(row1 * sizeof(double*));
	X = (double**)malloc(row1 * sizeof(double*));
	W = (double**)malloc(column * sizeof(double*));
    	for(i = 0; i < row1; i++){
		matrix1[i] = (double*)malloc(newCol * sizeof(double));
        	for(j = 0; j < newCol; j++)
            		fscanf(trainPointer,"%lf,", &matrix1[i][j]);
        	fscanf(trainPointer,"\n");
    	}
    	fclose(trainPointer);
    	testPointer = fopen(argv[2], "r");
    	fscanf(testPointer, "%d \n", &row2);
    	matrix2 = (double**)malloc(row2 * sizeof(double*));
    	for(i = 0;i < row2; i++){
		matrix2[i] = (double*)malloc(column * sizeof(double));
        	for(j = 0;j < column; j++)
            		fscanf(testPointer,"%lf,", &matrix2[i][j]);
        	fscanf(testPointer,"\n");
    	}
    	fclose(testPointer);    
    	for(i = 0; i < row1; i++){
		X[i] = (double*)malloc(newCol * sizeof(double));
        	X[i][0] = 1;
        	for(j = 1; j < newCol; j++)
            		X[i][j] = matrix1[i][j-1];
		Y[i] = (double*) malloc(sizeof(double));
		Y[i][0] = matrix1[i][column];
    	} 
    	for(i = 0; i < column; i++)
        	W[i] = (double*)malloc(sizeof(double));
    	weights = matrixMultiply(matrixMultiply(matrixInverse(matrixMultiply(matrixTranspose(X, row1, newCol), X, newCol, row1, row1, newCol), newCol), matrixTranspose(X, row1, newCol), newCol, newCol, newCol, row1), Y, newCol, row1, row1, 1);
    	for(i = 0; i < row2;i++){
		total = weights[0][0];
        	for(j = 0; j < column; j++)
                	total += weights[j+1][0] * matrix2[i][j];
        	printf("%0.0lf\n",total);
        	total = 0;
    	}
    	return 0;
}
