#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#define n 9
#define zero 0
bool numIsValid(int **grid, int r, int c, int num){
   	int i, j, row = r - (r%3), col = c - (c%3);
	for(i = row; i < row+3; i++)
		for(j = col; j < col+3; j++)
			if(grid[i][j] == num)
				return false;
	for(j = 0; j < n; j++)
		if(grid[j][c] == num || grid[r][j] == num)
    			return false;
    	return true;
}
bool check(int **grid){
	int i, j, k, temp;
	for(i = 0; i < n; i++)
		for(j = 0; j < n; j++){
			temp = grid[i][j];
			for(k = 0; k < n; k++)
				if((grid[k][j] == temp && k != i) || temp == 0 || (grid[i][k] == temp && k != j) || (temp > 9 || temp < 1))
					return false;
		}
	return true;
}

bool sudokuSolver(int **grid){
	int i, j, k;
	for(i = 0; i < n; i++)
		for(j = 0; j < n; j++)
			if(grid[i][j] == zero){
				for(k = 1; k <= n; k++)
					if(numIsValid(grid, i, j, k) == true){
						grid[i][j] = k;		
						if(sudokuSolver(grid)){
							
							return true;
						}
						else
							grid[i][j] = zero;
					}
			return false;
			}
	
	return true;
}
int main(int argc, char **argv){
	FILE *fp = fopen(argv[1], "r");
	int i,j, **matrix,  sol = 0;
	matrix = (int **) malloc(n * sizeof(int *));	
	for(i = 0; i < n; i++){
		matrix[i] = (int *) malloc(n * sizeof(int));
		for(j = 0; j < n; j++)
			fscanf(fp, "%d\t", &matrix[i][j]);
		fscanf(fp, "\n");
	}
	sol = sudokuSolver(matrix);
	if(sol){
		if(check(matrix))
			for(i = 0; i < n; i++){
				for(j = 0; j < n; j++){
					if(j == n-1)
						printf("%d", matrix[i][j]);	
					else
						printf("%d\t", matrix[i][j]);
				}	
				printf("\n");	
			}
		else
			printf("no-solution");	
	}
	return 0;
}
